const input = document.querySelector('.input-output');
const output = document.querySelector('.output-output');
let shouldClear = false;

function insert(num) {
  if (shouldClear) {
    clearOutput();
    shouldClear = false;
  }
  if (input.innerHTML === '0') {
    input.innerHTML = '';
  }
  if (input.innerHTML !== '' || !isOperator(num)) {
    input.innerHTML += num;
  }
}

function isOperator(value) {
  return value === '+' || value === '-' || value === '*' || value === '/';
}

function clearOutput() {
  input.innerHTML = '0';
  output.innerHTML = '0';
}

function backspace() {
  let inputString = input.innerHTML;
  if (inputString.length === 1) {
    input.innerHTML = '0';
  } else {
    input.innerHTML = inputString.slice(0, -1);
  }
}

function calculate() {
  let inputString = input.innerHTML;
  if (inputString === '0') {
    return;
  }
  if (!isOperator(inputString.slice(-1))) {
    try {
      const result = eval(inputString);
      output.innerHTML = result;
      input.innerHTML = result;
      shouldClear = true;
    } catch (error) {
      output.innerHTML = 'Error';
    }
  }
}

const buttons = document.querySelectorAll('button');
buttons.forEach((button) => {
  button.addEventListener('click', () => {
    if (button.innerHTML === 'Backspace') {
      backspace();
    } else if (button.innerHTML === 'Clear') {
      clearOutput();
    } else if (button.innerHTML === '=') {
      calculate();
    } else {
      insert(button.innerHTML);
    }
  });
});
